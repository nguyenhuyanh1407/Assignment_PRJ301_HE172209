/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package controller.dashboard;

import controller.auth.BaseRequiredAuthenticationController;
import dal.LeaveRequestDBContext;
import jakarta.servlet.RequestDispatcher;
import java.io.IOException;
import java.io.PrintWriter;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import java.lang.System.Logger;
import java.lang.System.Logger.Level;
import java.util.List;
import model.LeaveRequest;
import model.User;

/**
 *
 * @author ibm
 */
public class ControllerDashboardStaff extends BaseRequiredAuthenticationController {
    
    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp, User user) throws ServletException, IOException {
            
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response, User user) throws ServletException, IOException {
        System.out.println(user.getUsername());
        LeaveRequestDBContext db = new LeaveRequestDBContext();
        List<LeaveRequest> leaveRequests = db.getLeaveRequestsByUsername(user.getUsername());
        request.setAttribute("leaveRequests", leaveRequests);
        request.getRequestDispatcher("../view/dashboard/staff.jsp").forward(request, response);
    }

}