package controller.auth;

import controller.GoogleLoginController;
import dal.UserDBContext;
import model.GoogleAccount;
import model.User;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import java.io.IOException;

public class ControllerLogin extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        String code = request.getParameter("code");
        String error = request.getParameter("error");
        //neu nguoi dung huy uy quyen
        if (error != null) {
            request.getRequestDispatcher("login.jsp").forward(request, response);
        }
        if (code != null) {
            request.getRequestDispatcher("homepage").forward(request, response);

        }
        GoogleLoginController gg = new GoogleLoginController();
        String accessToken = gg.getToken(code);
        System.out.println(accessToken);
        GoogleAccount acc = gg.getUserInfo(accessToken);
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {
        String username = req.getParameter("username");
        String password = req.getParameter("password");
        String code = req.getParameter("code");

        UserDBContext db = new UserDBContext();
        User user = db.get(username, password);

        if (user != null) {

            HttpSession session = req.getSession();
            session.setAttribute("user", user);
            resp.sendRedirect("homepage");
        } else {
            resp.getWriter().println("login failed!");
        }
    }
}
