/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package view.dashboard;

import controller.auth.BaseRequiredAuthenticationController;
import dal.LeaveRequestDBContext;
import java.io.IOException;
import java.io.PrintWriter;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.util.List;
import model.LeaveRequest;
import model.User;

/**
 *
 * @author ibm
 */
public class ViewDashBoard extends BaseRequiredAuthenticationController
{

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp, User user) throws ServletException, IOException {
    }

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp, User user) throws ServletException, IOException {
            LeaveRequestDBContext db = new LeaveRequestDBContext();
        List<LeaveRequest> leaveRequests = db.getLeaveRequestsByUsername(user.getUsername());

        // Đặt danh sách vào request để truyền sang JSP
        req.setAttribute("leaveRequests", leaveRequests);
        resp.sendRedirect(req.getContextPath() + "/view/dashboard/staff.jsp");

    }

}
